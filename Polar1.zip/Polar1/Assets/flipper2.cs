﻿using System;

namespace AssemblyCSharp
{
	public class flipper2
	{
		public flipper2 ()
		{
		}
	}
}

