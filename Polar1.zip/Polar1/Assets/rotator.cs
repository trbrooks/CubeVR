﻿using UnityEngine;
using System.Collections;

public class rotator : MonoBehaviour {
	public Transform target;
	void Update() {
		transform.rotation = Quaternion.LookRotation(-Camera.main.transform.forward, Camera.main.transform.up);	}
}