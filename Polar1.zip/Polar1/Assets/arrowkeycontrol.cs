﻿using UnityEngine;
using System.Collections;

public class arrowkeycontrol : MonoBehaviour {
	public int speed = 10;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

		if (Input.GetKey (KeyCode.RightArrow)) {
			if (Input.GetKey (KeyCode.RightCommand)) {
				Vector3 v3 = new Vector3 (Input.GetAxis ("Vertical"), Input.GetAxis ("Horizontal"), 0);
				transform.Rotate (v3, speed * Time.deltaTime);
			} else {
				transform.Translate (new Vector3 (speed * Time.deltaTime, 0, 0));
			}
		}
		if (Input.GetKey (KeyCode.LeftArrow)) {
			if (Input.GetKey (KeyCode.RightCommand)) {
				Vector3 v3 = new Vector3 (Input.GetAxis ("Vertical"), Input.GetAxis ("Horizontal"), 0);
				transform.Rotate (v3, speed * Time.deltaTime);
			} else {
				transform.Translate (new Vector3 (-speed * Time.deltaTime, 0, 0));
			}
		}
		if (Input.GetKey (KeyCode.DownArrow)) {
			if (Input.GetKey (KeyCode.RightShift)) {
				transform.Translate (new Vector3 (0, -speed * Time.deltaTime, 0));
			} else if (Input.GetKey (KeyCode.RightCommand)) {
				Vector3 v3 = new Vector3(Input.GetAxis("Vertical"), Input.GetAxis("Horizontal"), 0);
				transform.Rotate(v3,-speed*Time.deltaTime);
			} else {
				transform.Translate (new Vector3 (0, 0, -speed * Time.deltaTime));
			}
		}
		if (Input.GetKey (KeyCode.UpArrow)) {
			if (Input.GetKey (KeyCode.RightShift)) {
				transform.Translate (new Vector3 (0, speed * Time.deltaTime, 0));
			} else if (Input.GetKey (KeyCode.RightCommand)) {
				Vector3 v3 = new Vector3(Input.GetAxis("Vertical"), Input.GetAxis("Horizontal"), 0);
				transform.Rotate(v3,-speed*Time.deltaTime);
			} else {
				transform.Translate (new Vector3 (0, 0, speed * Time.deltaTime));
			}
		}
	}
}