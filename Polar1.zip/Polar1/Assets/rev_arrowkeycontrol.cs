﻿using UnityEngine;
using System.Collections;

public class rev_arrowkeycontrol : MonoBehaviour {
	public int speed = 10;
	private int rev = 1;
	void Flip() {
		rev = -rev;
	}
	// Use this for initialization
	void Start () {
		InvokeRepeating("Flip", 3.0f, 3.0f);
			
	}
	
	// Update is called once per frame
	void Update () {
		
		if (Input.GetKey (KeyCode.RightArrow)) {
			if (Input.GetKey (KeyCode.RightCommand)) {
				Vector3 v3 = new Vector3 (Input.GetAxis ("Vertical"), Input.GetAxis ("Horizontal"), 0);
				transform.Rotate (v3, rev * speed * Time.deltaTime);
			} else {
				transform.Translate (new Vector3 (rev * speed * Time.deltaTime, 0, 0));
			}
		}
		if (Input.GetKey (KeyCode.LeftArrow)) {
			if (Input.GetKey (KeyCode.RightCommand)) {
				Vector3 v3 = new Vector3 (Input.GetAxis ("Vertical"), Input.GetAxis ("Horizontal"), 0);
				transform.Rotate (v3, rev * speed * Time.deltaTime);
			} else {
				transform.Translate (new Vector3 (rev * -speed * Time.deltaTime, 0, 0));
			}
		}
		if (Input.GetKey (KeyCode.DownArrow)) {
			if (Input.GetKey (KeyCode.RightShift)) {
				transform.Translate (new Vector3 (0, rev * -speed * Time.deltaTime, 0));
			} else if (Input.GetKey (KeyCode.RightCommand)) {
				Vector3 v3 = new Vector3(Input.GetAxis("Vertical"), Input.GetAxis("Horizontal"), 0);
				transform.Rotate(v3, rev * -speed*Time.deltaTime);
			} else {
				transform.Translate (new Vector3 (0, 0, rev * -speed * Time.deltaTime));
			}
		}
		if (Input.GetKey (KeyCode.UpArrow)) {
			if (Input.GetKey (KeyCode.RightShift)) {
				transform.Translate (new Vector3 (0, rev * speed * Time.deltaTime, 0));
			} else if (Input.GetKey (KeyCode.RightCommand)) {
				Vector3 v3 = new Vector3(Input.GetAxis("Vertical"), Input.GetAxis("Horizontal"), 0);
				transform.Rotate(v3,rev * -speed*Time.deltaTime);
			} else {
				transform.Translate (new Vector3 (0, 0, rev * speed * Time.deltaTime));
			}
		}
	}
}