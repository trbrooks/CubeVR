﻿using System;
//using SphericalCoordinates;

namespace AssemblyCSharp
{
	public class GetAngle
	{
		public GetAngle ()
		{
			// get the camera location into an object called v3

			Vector3 v3 = new Vector3 (Input.GetAxis ("Vertical"), Input.GetAxis ("Horizontal"), 0);

			// calculate how far it has strayed from the origin line
			SphericalCoordinates sc = new SphericalCoordinates();

		}
	}
}

